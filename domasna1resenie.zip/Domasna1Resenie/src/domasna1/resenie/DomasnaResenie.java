package domasna1.resenie;

public class DomasnaResenie {

	public static void main(String[] args) {
		System.out.println("Hello World OOP FIKT");

	}

}
